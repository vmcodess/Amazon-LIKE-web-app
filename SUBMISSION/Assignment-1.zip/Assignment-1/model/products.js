const products=
{
    fakeDB:[],

    init()
    {

        this.fakeDB.push({
        title :'Razer DeathAdder Elite Gaming Mouse',
        description :`16,000 DPI Optical Sensor - Chroma RGB Lighting - 7 Programmable Buttons - Mechanical Switches - Rubber Side Grips - Classic Black`,
        price :`$69.99`,
        category : `Electronics`,
        boolean : true,
        productImg : `/img/product1.jpg`
        });
    
        this.fakeDB.push({
        title :'HyperX QuadCast',
        description :`USB Condenser Gaming Microphone, for PC, PS4 and Mac, Anti-Vibration Shock Mount, Four Polar Patterns, Pop Filter, Gain Control, Podcasts, Twitch, YouTube, Discord, Red LED - Black`,
        price :`$175.99`,
        category : `Electronics`,
        boolean : true,
        productImg : `/img/product2.jpg`
        });
    
        this.fakeDB.push({
        title :'Logitech C922',
        description :`Pro Stream Webcam 1080P Camera for HD Video Streaming`,
        price :`$129.99`,
        category : `Electronics`,
        boolean : true,
        productImg : `/img/product3.png`
        });

        this.fakeDB.push({
        title : `VicTsing Essential Oil Diffuser`,
        description : `150ml Mini Aroma Wood Grain Cool Mist Humidifier for Office Home Study Yoga Spa Baby, Auto Shut-Off and 14 Color Night Lights (Dark Brown)`,
        price : `$29.99`,
        category : `Beauty & Personal Care`,
        boolean : true,
        productImg : `/img/product4.jpg`
        });

        this.fakeDB.push({
        title : `The Subtle Art of Not Giving a F*ck`,
        description : `A Counterintuitive Approach to Living a Good Life`,
        price : `$13.99`,
        category : `Books`,
        boolean : true,
        productImg : `/img/product5.png`
        });

        this.fakeDB.push({
        title : `AirPods`,
        description : `AirPods deliver effortless, all-day audio on the go. And AirPods Pro bring Active Noise Cancellation to an in-ear headphone — with a customizable fit.`,
        price : `$219`,
        category : `Electronics`,
        boolean : true,
        productImg : `/img/product6.jpg`
        });
    },

    getAllProducts()
    {
        return this.fakeDB;
    }

}

products.init();
module.exports=products;